import { useState, useEffect } from 'react';
import { Copy, Check } from 'lucide-react';

/**
 * Design: Minimalismo Científico Moderno
 * Paleta: Azul profundo (#1e40af), Branco, Cinza neutro
 * Tipografia: Playfair Display (títulos), Inter (corpo), Fira Code (código)
 * Layout: Grid assimétrico com espaço em branco generoso
 */

interface CodeExample {
  id: string;
  title: string;
  description: string;
  code: string;
  language?: string;
}

export default function Home() {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    // Highlight.js initialization
    const hljs = (window as any).hljs;
    if (hljs) {
      document.querySelectorAll('pre code').forEach((el) => {
        hljs.highlightElement(el as HTMLElement);
      });
    }
  }, []);

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const codeExamples: CodeExample[] = [
    {
      id: 'ex1',
      title: 'Criação Básica de Matriz',
      description: 'Criar uma matriz simples com 2 linhas e 2 colunas usando a função matrix()',
      code: `# Criar uma matriz 2x2
A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)
A

# Resultado:
#      [,1] [,2]
# [1,]    1    3
# [2,]    2    4`,
      language: 'r'
    },
    {
      id: 'ex2',
      title: 'Preenchimento por Linha',
      description: 'Usar o argumento byrow = TRUE para preencher a matriz por linha em vez de coluna',
      code: `# Preencher por linha
B <- matrix(c(1, 2, 3, 4, 5, 6), nrow = 2, ncol = 3, byrow = TRUE)
B

# Resultado:
#      [,1] [,2] [,3]
# [1,]    1    2    3
# [2,]    4    5    6`,
      language: 'r'
    },
    {
      id: 'ex3',
      title: 'Acesso a Elementos',
      description: 'Acessar elementos específicos de uma matriz usando índices [linha, coluna]',
      code: `# Acessar elemento na linha 1, coluna 2
A[1, 2]  # Retorna: 3

# Acessar toda a primeira linha
A[1, ]   # Retorna: 1 3

# Acessar toda a segunda coluna
A[, 2]   # Retorna: 3 4`,
      language: 'r'
    },
    {
      id: 'ex4',
      title: 'Soma de Matrizes',
      description: 'Somar duas matrizes de mesma dimensão elemento a elemento',
      code: `A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)
B <- matrix(c(5, 6, 7, 8), nrow = 2, ncol = 2)

# Soma
C <- A + B
C

# Resultado:
#      [,1] [,2]
# [1,]    6   10
# [2,]    8   12`,
      language: 'r'
    },
    {
      id: 'ex5',
      title: 'Multiplicação Matricial',
      description: 'Multiplicar duas matrizes usando o operador %*%',
      code: `A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)
B <- matrix(c(5, 6, 7, 8), nrow = 2, ncol = 2)

# Multiplicação matricial
C <- A %*% B
C

# Resultado:
#      [,1] [,2]
# [1,]   19   22
# [2,]   43   50`,
      language: 'r'
    },
    {
      id: 'ex6',
      title: 'Transposta de Matriz',
      description: 'Transpor uma matriz (trocar linhas por colunas) usando t()',
      code: `A <- matrix(c(1, 2, 3, 4, 5, 6), nrow = 2, ncol = 3)
A

# Transposta
At <- t(A)
At

# Resultado:
#      [,1] [,2]
# [1,]    1    4
# [2,]    2    5
# [3,]    3    6`,
      language: 'r'
    },
    {
      id: 'ex7',
      title: 'Determinante de Matriz',
      description: 'Calcular o determinante de uma matriz quadrada usando det()',
      code: `A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)

# Determinante
d <- det(A)
d

# Resultado: -2
# Cálculo: (1 × 4) - (2 × 3) = 4 - 6 = -2`,
      language: 'r'
    },
    {
      id: 'ex8',
      title: 'Inversa de Matriz',
      description: 'Calcular a inversa de uma matriz quadrada invertível usando solve()',
      code: `A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)

# Inversa
Ainv <- solve(A)
Ainv

# Verificação: A %*% Ainv = I (matriz identidade)
A %*% Ainv`,
      language: 'r'
    }
  ];

  return (
    <div className="min-h-screen bg-white text-foreground">
      {/* Navegação Fixa */}
      <nav className="fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-50 shadow-sm">
        <div className="container flex justify-between items-center h-16">
          <div className="text-2xl font-bold" style={{color: '#1e40af'}}>R Matrices</div>
          <div className="hidden md:flex gap-8">
            <a href="#historico" className="text-gray-600 transition-colors hover:opacity-70">Histórico</a>
            <a href="#funcionalidades" className="text-gray-600 transition-colors hover:opacity-70">Funcionalidades</a>
            <a href="#exemplos" className="text-gray-600 transition-colors hover:opacity-70">Exemplos</a>
            <a href="#aplicacao" className="text-gray-600 transition-colors hover:opacity-70">Aplicação Real</a>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-32" style={{background: 'linear-gradient(to bottom right, #ffffff, #dbeafe)'}}>
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-in-up">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight" style={{color: '#1e40af'}}>
                Estrutura das Matrizes na Linguagem R
              </h1>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Aprenda de forma clara e didática como trabalhar com matrizes em R, desde conceitos fundamentais até aplicações práticas em problemas reais.
              </p>
              <div className="flex gap-4">
                <a href="#funcionalidades" className="text-white px-6 py-3 rounded-lg font-medium transition-colors" style={{backgroundColor: '#1e40af'}}>
                  Começar Agora
                </a>
                <a href="#historico" className="border-2 px-6 py-3 rounded-lg font-medium transition-colors" style={{borderColor: '#1e40af', color: '#1e40af'}}>
                  Histórico
                </a>
              </div>
            </div>
            <div className="animate-slide-in-right hidden md:block">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663198562819/eEwQgdBrmemJyuafLB4pEB/hero-matrices-boaz4rYCF8osMBv4JwVzPn.webp"
                alt="Visualização de Matrizes"
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Seção: Histórico */}
      <section id="historico" className="section" style={{backgroundColor: '#ffffff'}}>
        <div className="container">
          <h2 className="section-title text-center" style={{color: '#1e40af'}}>Histórico das Matrizes</h2>
          <p className="section-subtitle text-center max-w-3xl mx-auto">
            Conheça a fascinante jornada do desenvolvimento das matrizes na matemática
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mb-16">
            <div className="animate-slide-in-left">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663198562819/eEwQgdBrmemJyuafLB4pEB/history-section-FiA7LCuDyncdhiuooofT7z.webp"
                alt="Desenvolvimento das Matrizes"
                className="w-full h-auto rounded-lg shadow-lg"
              />
            </div>
            <div className="animate-slide-in-right space-y-6">
              <div className="border-l-4 pl-6 py-4" style={{borderColor: '#1e40af'}}>
                <h3 className="text-xl font-bold mb-2" style={{color: '#1e40af'}}>Século XVIII - Origens</h3>
                <p className="text-gray-600">
                  O conceito de matrizes surgiu do estudo de sistemas de equações lineares. Matemáticos como Leibniz e Cramer desenvolveram métodos para resolver estes sistemas.
                </p>
              </div>

              <div className="border-l-4 pl-6 py-4" style={{borderColor: '#1e40af'}}>
                <h3 className="text-xl font-bold mb-2" style={{color: '#1e40af'}}>1855 - Arthur Cayley</h3>
                <p className="text-gray-600">
                  Arthur Cayley publicou trabalhos fundamentais sobre a teoria das matrizes, estabelecendo as operações básicas e propriedades algébricas que usamos até hoje.
                </p>
              </div>

              <div className="border-l-4 pl-6 py-4" style={{borderColor: '#1e40af'}}>
                <h3 className="text-xl font-bold mb-2" style={{color: '#1e40af'}}>1850s-1860s - James Joseph Sylvester</h3>
                <p className="text-gray-600">
                  Sylvester contribuiu significativamente com a notação de matrizes e o desenvolvimento de invariantes matriciais, consolidando a teoria moderna.
                </p>
              </div>

              <div className="border-l-4 pl-6 py-4" style={{borderColor: '#1e40af'}}>
                <h3 className="text-xl font-bold mb-2" style={{color: '#1e40af'}}>Importância Contemporânea</h3>
                <p className="text-gray-600">
                  Matrizes são fundamentais em matemática, estatística, física, engenharia, computação gráfica, machine learning e praticamente todas as ciências aplicadas.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção: Matrizes em R */}
      <section id="funcionalidades" className="section" style={{backgroundColor: '#f9fafb'}}>
        <div className="container">
          <h2 className="section-title text-center" style={{color: '#1e40af'}}>Matrizes na Linguagem R</h2>
          <p className="section-subtitle text-center max-w-3xl mx-auto">
            Compreenda a estrutura e funcionalidade das matrizes em R
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
            <div className="space-y-6">
              <div className="bg-white p-8 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>O que é uma Matriz em R?</h3>
                <p className="text-gray-600 leading-relaxed">
                  Uma matriz em R é uma estrutura de dados bidimensional (linhas e colunas) que armazena elementos do mesmo tipo. Diferente de um data frame, todos os elementos devem ser do mesmo tipo de dado (numérico, caractere, lógico, etc.).
                </p>
              </div>

              <div className="bg-white p-8 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>Estrutura Bidimensional</h3>
                <p className="text-gray-600 leading-relaxed mb-4">
                  Uma matriz é organizada em linhas (horizontais) e colunas (verticais). Cada elemento é identificado por sua posição [linha, coluna].
                </p>
                <div className="bg-gray-100 p-4 rounded text-sm font-mono" style={{color: '#1e40af'}}>
                  Matriz[i, j] onde i = linha, j = coluna
                </div>
              </div>

              <div className="bg-white p-8 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>Função matrix()</h3>
                <p className="text-gray-600 leading-relaxed mb-4">
                  A função principal para criar matrizes em R é <code className="bg-gray-100 px-2 py-1 rounded text-sm">matrix()</code>
                </p>
                <div className="space-y-2 text-sm text-gray-600">
                  <p><strong>Argumentos principais:</strong></p>
                  <ul className="list-disc list-inside space-y-1 ml-2">
                    <li><code className="bg-gray-100 px-1 rounded">data</code> - vetor com os elementos</li>
                    <li><code className="bg-gray-100 px-1 rounded">nrow</code> - número de linhas</li>
                    <li><code className="bg-gray-100 px-1 rounded">ncol</code> - número de colunas</li>
                    <li><code className="bg-gray-100 px-1 rounded">byrow</code> - TRUE para preencher por linha</li>
                  </ul>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white p-8 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>Exemplo Básico</h3>
                <div className="relative">
                  <pre className="code-block text-sm"><code className="language-r">{`A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)
A

#      [,1] [,2]
# [1,]    1    3
# [2,]    2    4`}</code></pre>
                  <button
                    onClick={() => copyToClipboard(`A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)\nA`, 'ex-basic')}
                    className="copy-button"
                  >
                    {copiedId === 'ex-basic' ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                </div>
              </div>

              <div className="bg-white p-8 rounded-lg border border-gray-200 hover:shadow-lg transition-shadow">
                <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>Operações Principais</h3>
                <div className="space-y-3 text-sm">
                  <div className="flex items-start gap-3">
                    <span className="font-bold" style={{color: '#f97316'}}>+</span>
                    <div>
                      <p className="font-semibold text-gray-900">Soma: A + B</p>
                      <p className="text-gray-600">Soma elemento a elemento</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="font-bold" style={{color: '#f97316'}}>×</span>
                    <div>
                      <p className="font-semibold text-gray-900">Multiplicação: A %*% B</p>
                      <p className="text-gray-600">Multiplicação matricial</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="font-bold" style={{color: '#f97316'}}>T</span>
                    <div>
                      <p className="font-semibold text-gray-900">Transposta: t(A)</p>
                      <p className="text-gray-600">Troca linhas por colunas</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="font-bold" style={{color: '#f97316'}}>|</span>
                    <div>
                      <p className="font-semibold text-gray-900">Determinante: det(A)</p>
                      <p className="text-gray-600">Valor escalar da matriz</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <span className="font-bold" style={{color: '#f97316'}}>⁻¹</span>
                    <div>
                      <p className="font-semibold text-gray-900">Inversa: solve(A)</p>
                      <p className="text-gray-600">Matriz inversa (se existir)</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-l-4 p-6 rounded" style={{backgroundColor: '#dbeafe', borderColor: '#1e40af'}}>
                <p className="text-sm text-gray-700">
                  <strong>Dica:</strong> Use <code className="bg-white px-2 py-1 rounded text-xs">dim(A)</code> para verificar as dimensões, <code className="bg-white px-2 py-1 rounded text-xs">nrow(A)</code> para linhas e <code className="bg-white px-2 py-1 rounded text-xs">ncol(A)</code> para colunas.
                </p>
              </div>
            </div>
          </div>

          <div className="mt-16 p-8 bg-white rounded-lg border-2" style={{borderColor: '#1e40af'}}>
            <h3 className="text-2xl font-bold mb-6" style={{color: '#1e40af'}}>Exemplo Completo</h3>
            <div className="relative">
              <pre className="code-block text-sm"><code className="language-r">{`# Criar duas matrizes
A <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)
B <- matrix(c(5, 6, 7, 8), nrow = 2, ncol = 2)

# Operações
soma <- A + B           # Soma elemento a elemento
mult <- A %*% B         # Multiplicação matricial
transp <- t(A)          # Transposta
det_A <- det(A)         # Determinante
inv_A <- solve(A)       # Inversa

# Visualizar resultados
print("Soma:")
print(soma)
print("Multiplicação Matricial:")
print(mult)`}</code></pre>
              <button
                onClick={() => copyToClipboard(`# Criar duas matrizes\nA <- matrix(c(1, 2, 3, 4), nrow = 2, ncol = 2)\nB <- matrix(c(5, 6, 7, 8), nrow = 2, ncol = 2)\n\n# Operações\nsoma <- A + B\nmult <- A %*% B\ntransp <- t(A)\ndet_A <- det(A)\ninv_A <- solve(A)\n\nprint("Soma:")\nprint(soma)`, 'ex-completo')}
                className="copy-button"
              >
                {copiedId === 'ex-completo' ? <Check size={16} /> : <Copy size={16} />}
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Seção: Exemplos Práticos */}
      <section id="exemplos" className="section" style={{backgroundColor: '#ffffff'}}>
        <div className="container">
          <h2 className="section-title text-center" style={{color: '#1e40af'}}>Exemplos Práticos em R</h2>
          <p className="section-subtitle text-center max-w-3xl mx-auto">
            Explore diversos exemplos de criação, manipulação e operações com matrizes
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {codeExamples.map((example, index) => (
              <div 
                key={example.id}
                className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow animate-fade-in-up"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="p-6 border-b border-gray-200 bg-gray-50">
                  <h3 className="text-lg font-bold mb-2" style={{color: '#1e40af'}}>{example.title}</h3>
                  <p className="text-sm text-gray-600">{example.description}</p>
                </div>
                <div className="p-6 relative">
                  <pre className="code-block text-xs"><code className="language-r">{example.code}</code></pre>
                  <button
                    onClick={() => copyToClipboard(example.code, example.id)}
                    className="copy-button"
                  >
                    {copiedId === example.id ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Seção: Aplicação Real */}
      <section id="aplicacao" className="section" style={{backgroundColor: '#dbeafe'}}>
        <div className="container">
          <h2 className="section-title text-center" style={{color: '#1e40af'}}>Aplicação Real: Cálculo de Faturamento</h2>
          <p className="section-subtitle text-center max-w-3xl mx-auto">
            Veja como matrizes resolvem problemas práticos em negócios
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-start mb-12">
            <div className="space-y-6">
              <div className="bg-white p-8 rounded-lg border border-gray-200">
                <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>Cenário</h3>
                <p className="text-gray-600 leading-relaxed mb-4">
                  Uma empresa vende 3 produtos diferentes em 2 meses. Queremos calcular o faturamento total de cada produto usando multiplicação matricial.
                </p>
                <div className="bg-gray-50 p-4 rounded space-y-3 text-sm">
                  <p><strong>Dados:</strong></p>
                  <ul className="list-disc list-inside space-y-1 text-gray-600">
                    <li>Produto 1: 100 unidades (mês 1), 150 unidades (mês 2)</li>
                    <li>Produto 2: 80 unidades (mês 1), 120 unidades (mês 2)</li>
                    <li>Produto 3: 50 unidades (mês 1), 90 unidades (mês 2)</li>
                    <li>Preços: R$ 10, R$ 15, R$ 20</li>
                  </ul>
                </div>
              </div>

              <div className="bg-white p-8 rounded-lg border border-gray-200">
                <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>Solução Passo a Passo</h3>
                <div className="space-y-4 text-sm">
                  <div>
                    <p className="font-semibold text-gray-900 mb-2">1. Criar matriz de quantidades (3×2)</p>
                    <p className="text-gray-600">Cada linha = um produto, cada coluna = um mês</p>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-2">2. Criar matriz de preços (1×3)</p>
                    <p className="text-gray-600">Uma linha com os preços dos 3 produtos</p>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-2">3. Multiplicação matricial</p>
                    <p className="text-gray-600">preços %*% quantidade = faturamento por mês</p>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900 mb-2">4. Interpretar resultados</p>
                    <p className="text-gray-600">Cada coluna mostra o faturamento total do mês</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white p-8 rounded-lg border-2" style={{borderColor: '#1e40af'}}>
              <h3 className="text-xl font-bold mb-6" style={{color: '#1e40af'}}>Código R Completo</h3>
              <div className="relative">
                <pre className="code-block text-xs"><code className="language-r">{`# Matriz de quantidades (3 produtos × 2 meses)
quantidade <- matrix(
  c(100, 150,
    80,  120,
    50,  90),
  nrow = 3,
  byrow = TRUE
)

# Matriz de preços (1 × 3)
precos <- matrix(c(10, 15, 20), nrow = 1)

# Multiplicação matricial
# Resultado: 1×2 (faturamento por mês)
faturamento <- precos %*% quantidade

# Visualizar resultado
print("Faturamento por mês:")
print(faturamento)

# Resultado esperado:
# [,1]  [,2]
# 3850  5850

# Interpretação:
# Mês 1: R$ 3.850
# Mês 2: R$ 5.850`}</code></pre>
                <button
                  onClick={() => copyToClipboard(`quantidade <- matrix(
  c(100, 150,
    80,  120,
    50,  90),
  nrow = 3,
  byrow = TRUE
)

precos <- matrix(c(10, 15, 20), nrow = 1)

faturamento <- precos %*% quantidade

print("Faturamento por mês:")
print(faturamento)`, 'ex-aplicacao')}
                  className="copy-button"
                >
                  {copiedId === 'ex-aplicacao' ? <Check size={16} /> : <Copy size={16} />}
                </button>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-lg border border-gray-200">
            <h3 className="text-xl font-bold mb-4" style={{color: '#1e40af'}}>Por que Usar Matrizes?</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-500 mb-2">⚡</div>
                <h4 className="font-semibold text-gray-900 mb-2">Eficiência</h4>
                <p className="text-sm text-gray-600">Operações vetorizadas são muito mais rápidas que loops</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-500 mb-2">📊</div>
                <h4 className="font-semibold text-gray-900 mb-2">Clareza</h4>
                <p className="text-sm text-gray-600">Código mais legível e fácil de manter</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-bold text-orange-500 mb-2">🎯</div>
                <h4 className="font-semibold text-gray-900 mb-2">Escalabilidade</h4>
                <p className="text-sm text-gray-600">Funciona igualmente bem com dados pequenos ou grandes</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Seção: Conclusão */}
      <section className="section" style={{backgroundColor: '#ffffff'}}>
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="section-title" style={{color: '#1e40af'}}>Conclusão</h2>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              As matrizes são uma ferramenta fundamental na linguagem R, permitindo operações matemáticas eficientes e elegantes. Desde cálculos simples até análises complexas, o domínio de matrizes é essencial para qualquer profissional que trabalhe com dados e estatística.
            </p>
            <p className="text-lg text-gray-600 leading-relaxed mb-8">
              Pratique os exemplos apresentados, explore as operações e aplique esses conhecimentos em seus próprios projetos. Com o tempo, trabalhar com matrizes em R se tornará uma segunda natureza.
            </p>
            <div className="border-l-4 p-6 rounded text-left" style={{backgroundColor: '#dbeafe', borderColor: '#1e40af'}}>
              <p className="text-gray-700">
                <strong>Próximos passos:</strong> Explore funções avançadas como <code className="bg-white px-2 py-1 rounded text-xs">eigen()</code> para autovalores, <code className="bg-white px-2 py-1 rounded text-xs">svd()</code> para decomposição em valores singulares, e <code className="bg-white px-2 py-1 rounded text-xs">apply()</code> para operações por linha ou coluna.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Rodapé */}
      <footer className="text-white py-12" style={{backgroundColor: '#1e40af'}}>
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-lg mb-4">Sobre</h4>
              <p className="text-sm" style={{color: '#dbeafe'}}>
                Site educacional dedicado ao ensino de matrizes na linguagem R, com foco em clareza e aplicações práticas.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Seções</h4>
              <ul className="space-y-2 text-sm" style={{color: '#dbeafe'}}>
                <li><a href="#historico" className="hover:text-white transition-colors">Histórico</a></li>
                <li><a href="#funcionalidades" className="hover:text-white transition-colors">Funcionalidades</a></li>
                <li><a href="#exemplos" className="hover:text-white transition-colors">Exemplos</a></li>
                <li><a href="#aplicacao" className="hover:text-white transition-colors">Aplicação Real</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Recursos</h4>
              <ul className="space-y-2 text-sm" style={{color: '#dbeafe'}}>
                <li><a href="https://www.r-project.org/" className="hover:text-white transition-colors">R Project</a></li>
                <li><a href="https://www.rstudio.com/" className="hover:text-white transition-colors">RStudio</a></li>
                <li><a href="https://cran.r-project.org/" className="hover:text-white transition-colors">CRAN</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t pt-8 text-center text-sm" style={{borderColor: '#1e3a8a', color: '#dbeafe'}}>
            <p>Projeto acadêmico sobre Matrizes em R • {new Date().getFullYear()}</p>
            <p className="mt-2">Desenvolvido com foco em educação e clareza</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
